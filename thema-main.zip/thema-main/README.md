# Theme
JANGAN DIJUAL BELAKAN YE BWANG !!!
BUTUH LICENSE/PW CHAT TELE GUA
>> t.me/ArdhitaOfficial <<

Comand Run Install Thema

bash <(curl https://raw.githubusercontent.com/ardxryz/thema/main/install.sh)
